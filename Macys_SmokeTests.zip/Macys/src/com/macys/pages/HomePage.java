package com.macys.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage {
	WebDriver driver;
	public HomePage(WebDriver driver) {
		this.driver = driver;
	}
	//Calling the instance method of a null object.
	public void searchItem(String itemName)
	{
		WebElement searchBox = driver.findElement(By.id("globalSearchInputField"));
		 searchBox.sendKeys(itemName);
		 driver.findElement(By.id("subnavSearchSubmit")).click();

	}
}
