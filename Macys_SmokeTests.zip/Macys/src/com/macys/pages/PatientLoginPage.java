package com.macys.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PatientLoginPage {

	WebDriver driver;
	public PatientLoginPage(WebDriver driver) {
		 this.driver = driver;
	}
	public boolean login(String uname,String passWord)
	{
		WebElement uName= driver.findElement(By.id("username"));
		uName.clear();
		uName.sendKeys(uname);
		WebElement pWord= driver.findElement(By.id("password"));
		pWord.clear();
		pWord.sendKeys(passWord);
	   driver.findElement(By.name("submit")).sendKeys(Keys.ENTER);
	   return true;
	}
}
