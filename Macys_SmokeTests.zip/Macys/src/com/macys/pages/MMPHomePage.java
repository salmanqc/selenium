package com.macys.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class MMPHomePage {
	WebDriver driver;//ref variable
	public MMPHomePage(WebDriver driver) {
		 this.driver = driver;
	}
	public void navigateToPatientLoginPage()
	{
		driver.findElement(By.linkText("Patient Login")).click();
		driver.findElement(By.linkText("Login")).click();
	}
	public void navigateToAdminLoginPage()
	{
	 
	}
	 

}
//Video Exceptions